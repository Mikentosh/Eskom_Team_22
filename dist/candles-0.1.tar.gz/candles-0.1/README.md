# Eskom Team 22

Project repo for the Analyse sprint

# The 7 functions in this package will be documented later on in this file